function injected_main() {
    setInterval (function() {

        var player = document.getElementById('captcha_audio');
        player.playbackRate = 1.2;

    }, 300);
}